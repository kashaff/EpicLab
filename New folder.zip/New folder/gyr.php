<?Php
 

 $dbhost = 'localhost';
 $dbname = 'temp';
 $dbuser = 'root';
 $dbpass = '';


try{
   
   $dbcon = new PDO("mysql:host={$dbhost};dbname={$dbname}",$dbuser,$dbpass);
   $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }catch(PDOException $ex){
  	die($ex->getMessage());
  }
$stmt = $dbcon->prepare("SELECT * FROM dht11");
$stmt->execute();
$json=[];
while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);
    $json[]=array('Ax'=> $Ax,  'Ay'=> $Ay, 'Az'=> $Az, 'T'=> $T, 'Gx'=>$Gx, 'Gy'=>$Gy, 'Gz'=>$Gz, 'date'=>$date);
}
?>



<!doctype html>
<head>
	<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.2/raphael-min.js"></script>
  <script src="../morris.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.js"></script>
  <script src="lib/example.js"></script>
  <link rel="stylesheet" href="lib/example.css">
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.css">
  <link rel="stylesheet" href="../morris.css">

</head>
<body>

<div id="graph"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael.min.js"></script>
<script type="text/javascript">


// Use Morris.Area instead of Morris.Line
new Morris.Line({
  element: 'graph',
  behaveLikeLine: true,
  data: <?php echo json_encode($json);?>,
  xkey: 'date',
  ykeys: ['Gx','Gy','Gz'],
  labels: ['Gx','Gy','Gz']
});

new Morris.Line({
  element: 'graph',
  behaveLikeLine: true,
  data: <?php echo json_encode($json);?>,
  xkey: 'date',
  ykeys: ['Ax','Ay','Az'],
  labels: ['Ax','Ay','Az']
});



</script>
</body>
</html>